#ifndef STATECLASS_H
#define STATECLASS_H
#include <iostream>
#include <string>
#include <new>
#include <climits>
#include <fstream>

 using namespace std;



class state
{
	string name, abbreviation, capital, dateasstring, mpcity, timez1, timez2, daylight, date;
	unsigned int population, sqmiles;

public:
	void setname(string name);
	void setabbreviation(string abbreviation);
	void setcapital(string capital);
	void setmpcity(string mpcity);
	void settimez1(string timez1);
	void settimez2(string timez2);
	void setdaylight(string daylight);
	void setdate(string date);
	void setpopulation(unsigned int population);
	void setsqmiles(unsigned int sqmiles);

	string getname(void);
	string getabbreviation(void);
	string getcapital(void);
	string getmpcity(void);
	string gettimez1(void);
	string gettimez2(void);
	string getdaylight(void);
	string getdate(void);
	unsigned int getpopulation(void);
	unsigned int getsqmiles(void);
};

//cpp file
void state::setname(string name)
{
    this->name = name;
}
void state::setabbreviation(string abbreviation)
{

	this->abbreviation = abbreviation;
}
void state::setcapital(string capital)
{
	this->capital = capital;
}
void state::setmpcity(string mpcity)
{
	this->mpcity = mpcity;
}
void state::settimez1(string timez1)
{
	this->timez1 = timez1;
}
void state::settimez2(string timez2)
{
	this->timez2 = timez2;
}
void state::setdaylight(string daylight)
{
	this->daylight = daylight;
}
void state::setdate(string date)
{
	this->date = date;
}
void state::setpopulation(unsigned int population)
{
	this->population = population;
}
void state::setsqmiles(unsigned int sqmiles)
{
	this->sqmiles = sqmiles;
}

string state::getname(void)
{
	return name;
}
string state::getabbreviation(void)
{
	return abbreviation;
}
string state::getcapital(void)
{
	return capital;
}
string state::getmpcity(void)
{
	return mpcity;
}
string state::gettimez1(void)
{
	return timez1;
}
string state::gettimez2(void)
{
	return timez2;
}
string state::getdaylight(void)
{
	return daylight;
}
string state::getdate(void)
{
	return date;
}
unsigned int state::getpopulation(void)
{
	return population;
}
unsigned int state::getsqmiles(void)
{
	return sqmiles;
}
//cpp file

class Date
{
 public:
    unsigned short month;
    unsigned short day;
    unsigned short year;
};

#endif


