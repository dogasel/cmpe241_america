#ifndef STATECLASS_H
#define STATECLASS_H
#include <iostream>
#include <string>
#include <new>
#include <climits>
#include <fstream>

using namespace std;

class state
{

private:
    string name, abbreviation, capital, mpcity, timez1, timez2, daylight, date;
    unsigned int population, sqmiles;

public:
    state();
    state(string,string,string,string,string,string,string,string,unsigned int,unsigned int);
    void setname(string);
    void setabbreviation(string);
    void setcapital(string);
    void setmpcity(string);
    void settimez1(string);
    void settimez2(string);
    void setdaylight(string);
    void setdate(string);
    void setpopulation(unsigned int);
    void setsqmiles(unsigned int);

    string getname(void);
    string getabbreviation(void);
    string getcapital(void);
    string getmpcity(void);
    string gettimez1(void);
    string gettimez2(void);
    string getdaylight(void);
    string getdate(void);
    unsigned int getpopulation(void);
    unsigned int getsqmiles(void);
};

//cpp file
state::state(string name,string abbreviation,string capital,string mpcity,string timez1,string timez2,string daylight,string date,unsigned int population,unsigned int sqmiles)
{
    this->name = name;
    this->abbreviation = abbreviation;
    this->capital = capital;
    this->mpcity = mpcity;
    this->timez1 = timez1;
    this->timez2 = timez2;
    this->daylight = daylight;
    this->date = date;
    this->population = population;
    this->sqmiles = sqmiles;
}

state::state()
{
}

void state::setname(string name)
{
    this->name = name;
}
void state::setabbreviation(string abbreviation)
{
    this->abbreviation = abbreviation;
}
void state::setcapital(string capital)
{
    this->capital = capital;
}
void state::setmpcity(string mpcity)
{
    this->mpcity = mpcity;
}
void state::settimez1(string timez1)
{
    this->timez1 = timez1;
}
void state::settimez2(string timez2)
{
    this->timez2 = timez2;
}
void state::setdaylight(string daylight)
{
    this->daylight = daylight;
}
void state::setdate(string date)
{
    this->date = date;
}
void state::setpopulation(unsigned int population)
{
    this->population = population;
}
void state::setsqmiles(unsigned int sqmiles)
{
    this->sqmiles = sqmiles;
}

string state::getname(void)
{
    return name;
}
string state::getabbreviation(void)
{
    return abbreviation;
}
string state::getcapital(void)
{
    return capital;
}
string state::getmpcity(void)
{
    return mpcity;
}
string state::gettimez1(void)
{
    return timez1;
}
string state::gettimez2(void)
{
    return timez2;
}
string state::getdaylight(void)
{
    return daylight;
}
string state::getdate(void)
{
    return date;
}
unsigned int state::getpopulation(void)
{
    return population;
}
unsigned int state::getsqmiles(void)
{
    return sqmiles;
}
//cpp file

#endif


