#include <iostream>
#include <string>
#include <new>
#include <climits>
#include <fstream>
#include "stateclass.h"
#include "functions.h"



using namespace std;

int main()
{
    bool switchcase=false;
    unsigned short query;
    string selection;
    cout << "Select the query you want to run(1-6): ";
    getline(cin, selection);
    query=strtoint(selection);
    while(query<1 || query>6)
    {
        cerr << "Query out of bound please input new query!: ";
        getline(cin, selection);
        query=strtoint(selection);
    }
    switch (query)
    {
    case 1:
        query1();
        break;
    case 2:
        query2();
        break;
    case 3:
        query3();
        break;
    case 4:
        query4();
        break;
    case 5:
        query5();
        break;
    case 6:
        query6();
        break;
    }
}
