#include <iostream>
#include <string>
#include <new>
#include <climits>
#include <fstream>
#include "stateclass.h"
#include "functions.h"



using namespace std;

int main()
{
    statesfordate* kasim;
    unsigned short numofstates;
    kasim=structurefordates("us_states.xml",numofstates);
    sorterfordates(kasim,numofstates);
    statedateprinter(kasim,numofstates);

}
