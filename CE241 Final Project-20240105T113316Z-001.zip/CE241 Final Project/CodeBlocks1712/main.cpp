#include <iostream>
#include <string>
#include <new>
#include <climits>
#include <fstream>
#include "stateclass.h"
#include "functions.h"



using namespace std;

int main()
{

string state;
cout << "Type a name of state to retrieve info: ";

cin >> state;


string line, name = "us_states.xml";
ifstream txtFile("us_states.xml");

int counter;
string* arrayofelements;

if (txtFile.is_open())
{
	while (getline(txtFile, line))
    {
        size_t pos = line.find(state);
        if (pos!=string::npos) //aldığı line içinde cin ile aldığımız state var ise
        {
            //count of items
            counter = 0;
            for (int i = 0; i < line.size(); i++)
            {
                if (line[i] == '"') counter++;
            }
            counter=counter/2;
            //count of items
            arrayofelements = new (nothrow) string[counter];
            unsigned short k=0;


            for (int i=0; i<counter;i++)
            {

                char delimiter = '"';
                size_t pos = 0;
                size_t pos2 = 0;
                pos = line.find(delimiter);
                pos2 = line.find(delimiter, pos +1);
                size_t lenofasset = pos2-pos-1;
                string asset= line.substr(pos+1,lenofasset);
                line.erase(0,pos2+1);
                arrayofelements[k++]=asset;
            }


        }

    }

        //element getter

}
arrayprinter(arrayofelements,counter);
txtFile.close();
}



