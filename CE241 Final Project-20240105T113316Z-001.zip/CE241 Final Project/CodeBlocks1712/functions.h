#ifndef FUNCTIONS_H_INCLUDED
#define FUNCTIONS_H_INCLUDED
#include <iostream>
#include <string>
#include <new>
#include <climits>
#include <fstream>

unsigned short strtoint(string str)
{
    unsigned short ans=0;
    unsigned short times=1;
    for(int i=str.length()-1;i>=0;i--)
    {
        ans=ans+times*(str[i]-'0');
        times=times*10;
    }
    return ans;

}

void datetransfer(string dt)
{
    string year = dt.substr(0,4);
    string month = dt.substr(5,2);
    string day = dt.substr(8,2);
    unsigned short year2 = strtoint(year);
    unsigned short month2 = strtoint(month);
    unsigned short day2 = strtoint(day);

    string months[12] ={ "January", "February", "March", "April", "May", "June",
 "July", "August", "September", "October", "November", "December" };

    Date afa;

    afa.year=year2;
    afa.month=month2;
    afa.day=day2;

    cout << months[month2-1] <<" "<<day<<", "<<year2;

}




void arrayprinter(string *arr,int counter)
{
    for(int i=0;i<counter;i++)
    {
        if(counter==9)
        {
            if(i==0)
                cout << "State: "<<arr[i]<<endl;
            if(i==1)
                cout << "Abbreviation: "<<arr[i]<<endl;
            if(i==2)
                cout << "Capital: "<<arr[i]<<endl;
            if(i==3)
            {
                cout << "Date of admission: ";
                datetransfer(arr[i]);
                cout<<endl;
            }
            if(i==4)
                cout << "Most populous city: "<<arr[i]<<endl;
            if(i==5)
                cout << "Population: "<<arr[i]<<endl;
            if(i==6)
                cout << "Area: "<<arr[i]<< " mi2"<<endl;
            if(i==7)
                cout << "Time zones: "<<arr[i]<<endl;
            if(i==8)
                cout << "Dst: "<<arr[i]<<endl;
        }
        if(counter==10)
        {
            if(i==0)
                cout << "State: "<<arr[i]<<endl;
            if(i==1)
                cout << "Abbreviation: "<<arr[i]<<endl;
            if(i==2)
                cout << "Capital: "<<arr[i]<<endl;
            if(i==3)
            {
                cout << "Date of admission: ";
                datetransfer(arr[i]);
                cout<<endl;
            }
            if(i==4)
                cout << "Most populous city: "<<arr[i]<<endl;
            if(i==5)
                cout << "Population: "<<arr[i]<<endl;
            if(i==6)
                cout << "Area: "<<arr[i]<< " mi2"<<endl;
            if(i==7)
                cout << "Time zones: "<<arr[i]<<", "<<arr[i+1]<<endl;
            if(i==8)
                cout << "DST: "<<arr[i+1]<<endl;
        }

    }
}




#endif // FUNCTIONS_H_INCLUDED
