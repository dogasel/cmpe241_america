#ifndef FUNCTIONS_H_INCLUDED
#define FUNCTIONS_H_INCLUDED
#include <iostream>
#include <string>
#include <new>
#include <climits>
#include <fstream>


unsigned int strtoint(string str) //converts string to integer
{
    unsigned int ans=0;
    unsigned int times=1;
    for(int i=str.length()-1; i>=0; i--)
    {
        if(str[i]>='0' && str[i]<='9') // to use this function also in date to int conversion
        {
            ans=ans+times*(str[i]-'0');
            times=times*10;
        }
    }
    return ans;

}


void datetransfer(string dt) //converts date string to wanted date format
{
    string year = dt.substr(0,4);
    string month = dt.substr(5,2);
    string day = dt.substr(8,2);
    unsigned short year2 = strtoint(year);
    unsigned short month2 = strtoint(month);
    unsigned short day2 = strtoint(day);

    string months[12] = { "January", "February", "March", "April", "May", "June",
                              "July", "August", "September", "October", "November", "December"
                            };

    cout << months[month2-1] <<" "<<day<<", "<<year2;
}

string getnextelement(string &line) //finding the first element in a given string in between quotation marks
{
    char delimiter='"';
    string element;
    size_t pos1 = line.find(delimiter);
    size_t pos2 = line.find(delimiter, pos1 +1);
    size_t lenofasset = pos2-pos1-1;
    element=line.substr(pos1+1,lenofasset);
    line.erase(pos1,1);
    line.erase(pos2-1,1);
    return element;
}

 unsigned short counterofelements(string line) //finding the element count for each line
 {
    char delimiterforequal = '=';
    size_t posofequal=0;
    unsigned short counter=0;
    while((posofequal=line.find(delimiterforequal)) != string::npos)
    {
        counter++;
        line.erase(posofequal,1);
    }
    return counter;
 }

void swaperforquery4(state &item1,state &item2) //takes two objects and swaps their wanted items
{
    string tempforstate;
    string tempfordate;
    tempforstate=item1.getname();
    tempfordate=item1.getdate();
    item1.setname(item2.getname());
    item1.setdate(item2.getdate());
    item2.setname(tempforstate);
    item2.setdate(tempfordate);
}

void sorterforquery4(state* obj,unsigned short numofstates) //takes array of class and array length and sorts the array of class by their dates
{

    unsigned int date1;
    unsigned int date2;
    for(int i=0; i<numofstates-1; i++)
    {
        for(int j=i+1; j<numofstates; j++)
        {
            date1= strtoint(obj[i].getdate());
            date2= strtoint(obj[j].getdate());

            if(date1>date2)
            {
                swaperforquery4(obj[i],obj[j]);
            }


        }

    }
}

void printerforquery4(state* obj,unsigned short numofstates) //takes array of class and prints the data stored in array in desired order
{
    for(int i=0; i<numofstates; i++)
    {
        cout << obj[i].getname()<< " -> ";
        datetransfer(obj[i].getdate());
        cout<< endl;
    }
    delete[] obj;

}

void swaperforquery3(state &item1,state &item2) //takes two objects and swaps their wanted items
{
    string tempforstate;
    unsigned int tempforsqmiles;
    tempforstate=item1.getname();
    tempforsqmiles=item1.getsqmiles();
    item1.setname(item2.getname());
    item1.setsqmiles(item2.getsqmiles());
    item2.setname(tempforstate);
    item2.setsqmiles(tempforsqmiles);
}


void sorterforquery3(state* obj,unsigned short numofstates) //takes array of class and array length and sorts the array of class by their sqmiles
{
    for(int i=0; i<numofstates-1; i++)
    {
        for(int j=i+1; j<numofstates; j++)
        {

            if(obj[i].getsqmiles()<obj[j].getsqmiles())
            {
                swaperforquery3(obj[i],obj[j]);
            }


        }

    }
}

void printerforquery3(state* obj,unsigned short printcount) //takes array of class and prints the data stored in array in desired order
{
    for(int i=0;i<printcount;i++)
    {
        cout << obj[i].getname()<< endl;
    }
    delete[] obj;

}

void swaperforquery2(state &item1,state &item2) //takes two objects and swaps their wanted items
{
    string tempforcapital, tempforabbreviation;
    tempforcapital=item1.getcapital();
    tempforabbreviation=item1.getabbreviation();
    item1.setcapital(item2.getcapital());
    item1.setabbreviation(item2.getabbreviation());
    item2.setcapital(tempforcapital);
    item2.setabbreviation(tempforabbreviation);
}

void sorterforquery2(state *obj,unsigned short numofstates) //takes array of class and array length and sorts the array of class by their names
{
    for(int i=0; i<numofstates-1; i++)
    {
        for(int j=i+1; j<numofstates; j++)
        {

            int res = obj[i].getcapital().compare(obj[j].getcapital());
            if(res>0)
            {
                swaperforquery2(obj[i],obj[j]);
            }

        }

    }
}

void printerforquery2(state* obj,unsigned short numofstates) //takes array of class and prints the data stored in array in desired order
{
    for(int i=0;i<numofstates;i++)
    {
        cout << obj[i].getcapital() << " (" <<obj[i].getabbreviation() <<")"<< endl;
    }
    delete[] obj;

}

void printerforquery1(string filename) //takes the file, only stores the data user wanted and prints it out
{
    unsigned short countofelements;
    bool statefound=false;
    string statename;
    while (statefound==false)
    {
        cout << "Type a name of state to retrieve info: ";
        getline(cin,statename);
        statename[0] = toupper(statename[0]); //capitalise the first letter of input

        string line;
        ifstream xmlFile(filename);
        if (xmlFile.is_open())
        {
            while (getline(xmlFile, line))
            {
                size_t pos = line.find(statename);
                if (pos!=string::npos)
                {
                    statefound=true;
                }
            }
            xmlFile.close();
        }

        if(statefound==false)
            cerr << "State can not be found please enter new state!"<<endl;
    }


    string name, abbreviation, capital, mpcity, timez1, timez2, daylight, date;
	unsigned int population, sqmiles;

    string line;
    ifstream xmlFile(filename);
    if (xmlFile.is_open())
        {
            while (getline(xmlFile, line))
            {
                size_t pos = line.find(statename);
                if (pos!=string::npos)
                {
                    countofelements=counterofelements(line);
                    if(countofelements==9)
                    {
                        name=getnextelement(line);
                        abbreviation=getnextelement(line);
                        capital=getnextelement(line);
                        date=getnextelement(line);
                        mpcity=getnextelement(line);
                        population=strtoint(getnextelement(line));
                        sqmiles=strtoint(getnextelement(line));
                        timez1=getnextelement(line);
                        daylight=getnextelement(line);
                    }

                    else if(countofelements==10)
                    {
                        name=getnextelement(line);
                        abbreviation=getnextelement(line);
                        capital=getnextelement(line);
                        date=getnextelement(line);
                        mpcity=getnextelement(line);
                        population=strtoint(getnextelement(line));
                        sqmiles=strtoint(getnextelement(line));
                        timez1=getnextelement(line);
                        timez2=getnextelement(line);
                        daylight=getnextelement(line);
                    }
                }
            }
            xmlFile.close();

            state afa(name,abbreviation,capital,mpcity,timez1,timez2,daylight,date,population,sqmiles); //creating a class with overloaded constructor

            //printer
            if(countofelements==9)
            {
                cout << "State: "<<afa.getname()<<endl;
                cout << "Abbreviation: "<<afa.getabbreviation()<<endl;
                cout << "Capital: "<<afa.getcapital()<<endl;
                cout << "Date of admission: ";
                datetransfer(afa.getdate());
                cout<<endl;
                cout << "Most populous city: "<<afa.getmpcity()<<endl;
                cout << "Population: "<<afa.getpopulation()<<endl;
                cout << "Area: "<<afa.getsqmiles()<< " mi2"<<endl;
                cout << "Time zones: "<<afa.gettimez1()<<endl;
                cout << "DST: "<<afa.getdaylight()<<endl;
            }
            if(countofelements==10)
            {
                cout << "State: "<<afa.getname()<<endl;
                cout << "Abbreviation: "<<afa.getabbreviation()<<endl;
                cout << "Capital: "<<afa.getcapital()<<endl;
                cout << "Date of admission: ";
                datetransfer(afa.getdate());
                cout<<endl;
                cout << "Most populous city: "<<afa.getmpcity()<<endl;
                cout << "Population: "<<afa.getpopulation()<<endl;
                cout << "Area: "<<afa.getsqmiles()<< " mi2"<<endl;
                cout << "Time zones: "<<afa.gettimez1()<<", "<<afa.gettimez2()<<endl;
                cout << "DST: "<<afa.getdaylight()<<endl;
            }
            //printer
        }

}

state* xmlfilereader(string filename,unsigned short &numofstates) //takes a xml file and stores its data in array of class
{
    //xml file reader
    unsigned short countofelements;
    state* statedata;
    numofstates = 0;
    string line;
    ifstream xmlFile(filename);
    if (xmlFile.is_open())
    {
        // get num of states
        while (getline(xmlFile, line))
        {
            size_t pos = line.find("state name");
            if (pos!=string::npos)
            {
                numofstates++;
            }
        }
        xmlFile.close();
    }
        // get num of states

    statedata=new (nothrow) state[numofstates]; //create array of class for data storage


    unsigned short k=0; //counter for array of state(which is our class) index

    string line2;
    ifstream sel(filename);
    if (sel.is_open())
    {
        while (getline(sel, line2))
        {
            size_t pos = line2.find("state name"); //pos state name
            if (pos!=string::npos)
            {

                countofelements=counterofelements(line2);

                if(countofelements==9)
                {
                    statedata[k].setname(getnextelement(line2));
                    statedata[k].setabbreviation(getnextelement(line2));
                    statedata[k].setcapital(getnextelement(line2));
                    statedata[k].setdate(getnextelement(line2));
                    statedata[k].setmpcity(getnextelement(line2));
                    statedata[k].setpopulation(strtoint(getnextelement(line2)));
                    statedata[k].setsqmiles(strtoint(getnextelement(line2)));
                    statedata[k].settimez1(getnextelement(line2));
                    statedata[k++].setdaylight(getnextelement(line2));

                }
                else if(countofelements==10)
                {
                    statedata[k].setname(getnextelement(line2));
                    statedata[k].setabbreviation(getnextelement(line2));
                    statedata[k].setcapital(getnextelement(line2));
                    statedata[k].setdate(getnextelement(line2));
                    statedata[k].setmpcity(getnextelement(line2));
                    statedata[k].setpopulation(strtoint(getnextelement(line2)));
                    statedata[k].setsqmiles(strtoint(getnextelement(line2)));
                    statedata[k].settimez1(getnextelement(line2));
                    statedata[k].settimez2(getnextelement(line2));
                    statedata[k++].setdaylight(getnextelement(line2));
                }

            }

        }
    }
    sel.close();
    return statedata;
}


//functions to call in main
void query1()
{

    printerforquery1("us_states.xml");
}

void query2()
{
    unsigned short numofstates;
    state* doga = xmlfilereader("us_states.xml",numofstates);
    sorterforquery2(doga,numofstates);
    printerforquery2(doga,numofstates);
}

void query3()
{
    unsigned short numofstates;
    state* kasim = xmlfilereader("us_states.xml",numofstates);
    sorterforquery3(kasim,numofstates);
    printerforquery3(kasim,5);
}
void query4()
{
    unsigned short numofstates;
    state* enes = xmlfilereader("us_states.xml",numofstates);
    sorterforquery4(enes,numofstates);
    printerforquery4(enes,numofstates);
}
bool query5()
{
    unsigned short numofstates;
    state* fabio = xmlfilereader("us_states.xml",numofstates);
    unsigned int totalarea=0;
    for(unsigned short i=0;i<numofstates;i++)
    {
        if(totalarea>UINT_MAX-fabio[i].getsqmiles())
        {
            cout << "Overflow in area calculation!" << endl;
            return 0;
        }
        totalarea=totalarea+fabio[i].getsqmiles();
    }
    unsigned int overallarea=totalarea/numofstates;
    cout << "Overall area of United States is "<<overallarea<<" mi2"<<endl;
    delete[] fabio;
}
bool query6()
{
    unsigned short numofstates;
    state* dogakasimafa = xmlfilereader("us_states.xml",numofstates);
    unsigned int totalpop=0;
    for(unsigned short i=0;i<numofstates;i++)
    {
        if(totalpop>UINT_MAX-dogakasimafa[i].getpopulation())
        {
            cout << "Overflow in population calculation!" << endl;
            return 0;
        }
        totalpop=totalpop+dogakasimafa[i].getpopulation();
    }
    unsigned int overallpop=totalpop/numofstates;
    cout << "Overall population of United States is "<<overallpop<<endl;
    delete[] dogakasimafa;
}

#endif // FUNCTIONS_H_INCLUDED
