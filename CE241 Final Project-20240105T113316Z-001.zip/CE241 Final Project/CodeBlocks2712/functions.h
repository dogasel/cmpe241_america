#ifndef FUNCTIONS_H_INCLUDED
#define FUNCTIONS_H_INCLUDED
#include <iostream>
#include <string>
#include <new>
#include <climits>
#include <fstream>


unsigned int strtoint(string str) //converts string to integer
{
    unsigned int ans=0;
    unsigned int times=1;
    for(int i=str.length()-1; i>=0; i--)
    {
        if(str[i]!='-') // to use this function also in date to int conversion
        {
            ans=ans+times*(str[i]-'0');
            times=times*10;
        }
    }
    return ans;

}


void datetransfer(string dt)
{
    string year = dt.substr(0,4);
    string month = dt.substr(5,2);
    string day = dt.substr(8,2);
    unsigned short year2 = strtoint(year);
    unsigned short month2 = strtoint(month);
    unsigned short day2 = strtoint(day);

    string months[12] = { "January", "February", "March", "April", "May", "June",
                              "July", "August", "September", "October", "November", "December"
                            };


    cout << months[month2-1] <<" "<<day<<", "<<year2;



}



void swaperforquery4(state &item1,state &item2)
{
    string tempforstate;
    string tempfordate;
    tempforstate=item1.getname();
    tempfordate=item1.getdate();
    item1.setname(item2.getname());
    item1.setdate(item2.getdate());
    item2.setname(tempforstate);
    item2.setdate(tempfordate);
}

void sorterforquery4(state* obj,unsigned short numofstates)
{

    unsigned int date1;
    unsigned int date2;
    for(int i=0; i<numofstates-1; i++)
    {
        for(int j=i+1; j<numofstates; j++)
        {
            date1= strtoint(obj[i].getdate());
            date2= strtoint(obj[j].getdate());

            if(date1>date2)
            {
                swaperforquery4(obj[i],obj[j]);
            }


        }

    }
}


void printerforquery4(state* obj,unsigned short numofstates)
{
    for(int i=0; i<numofstates; i++)
    {
        cout << obj[i].getname()<< " -> ";
        datetransfer(obj[i].getdate());
        cout<< endl;
    }
    delete[] obj;

}

void swaperforquery3(state &item1,state &item2)
{
    string tempforstate;
    unsigned int tempforsqmiles;
    tempforstate=item1.getname();
    tempforsqmiles=item1.getsqmiles();
    item1.setname(item2.getname());
    item1.setsqmiles(item2.getsqmiles());
    item2.setname(tempforstate);
    item2.setsqmiles(tempforsqmiles);
}


void sorterforquery3(state* obj,unsigned short numofstates)
{
    for(int i=0; i<numofstates-1; i++)
    {
        for(int j=i+1; j<numofstates; j++)
        {

            if(obj[i].getsqmiles()<obj[j].getsqmiles())
            {
                swaperforquery3(obj[i],obj[j]);
            }


        }

    }
}

void printerforquery3(state* obj,unsigned short printcount)
{
    for(int i=0;i<printcount;i++)
    {
        cout << obj[i].getname()<< endl;
    }
    delete[] obj;

}


void swaperforquery2(state &item1,state &item2)
{
    string tempforcapital, tempforabbreviation;
    tempforcapital=item1.getcapital();
    tempforabbreviation=item1.getabbreviation();
    item1.setcapital(item2.getcapital());
    item1.setabbreviation(item2.getabbreviation());
    item2.setcapital(tempforcapital);
    item2.setabbreviation(tempforabbreviation);
}

void sorterforquery2(state *obj,unsigned short numofstates)
{
    for(int i=0; i<numofstates-1; i++)
    {
        for(int j=i+1; j<numofstates; j++)
        {

            int res = obj[i].getcapital().compare(obj[j].getcapital());
            if(res>0)
            {
                swaperforquery2(obj[i],obj[j]);
            }

        }

    }
}

void printerforquery2(state* obj,unsigned short numofstates)
{
    for(int i=0;i<numofstates;i++)
    {
        cout << obj[i].getcapital() << " (" <<obj[i].getabbreviation() <<")"<< endl;
    }
    delete[] obj;

}

void printerforquery1(state *arr,unsigned short numofstates)
{
    bool statefound=false;
    unsigned short i;
    string statename;
    while (statefound==false)
    {
        cout << "Type a name of state to retrieve info: ";
        getline(cin,statename);
        statename[0] = toupper(statename[0]); //capitalise the first letter of input
        for(i=0; i<numofstates; i++)
        {
            if(arr[i].getname()==statename)
            {
                statefound=true;
                break;
            }
        }
        if(statefound==false)
            cerr << "State can not be found please enter new state!"<<endl;
    }


    //set the element count by checking the timez2 element
    unsigned short counterofelements;

    counterofelements=10;
    if(arr[i].gettimez2()=="")
        counterofelements=9;
    //set the element count by checking the timez2 element

    if(counterofelements==9)
    {
        cout << "State: "<<arr[i].getname()<<endl;
        cout << "Abbreviation: "<<arr[i].getabbreviation()<<endl;
        cout << "Capital: "<<arr[i].getcapital()<<endl;
        cout << "Date of admission: ";
        datetransfer(arr[i].getdate());
        cout<<endl;
        cout << "Most populous city: "<<arr[i].getmpcity()<<endl;
        cout << "Population: "<<arr[i].getpopulation()<<endl;
        cout << "Area: "<<arr[i].getsqmiles()<< " mi2"<<endl;
        cout << "Time zones: "<<arr[i].gettimez1()<<endl;
        cout << "DST: "<<arr[i].getdaylight()<<endl;
    }
    if(counterofelements==10)
    {
        cout << "State: "<<arr[i].getname()<<endl;
        cout << "Abbreviation: "<<arr[i].getabbreviation()<<endl;
        cout << "Capital: "<<arr[i].getcapital()<<endl;
        cout << "Date of admission: ";
        datetransfer(arr[i].getdate());
        cout<<endl;
        cout << "Most populous city: "<<arr[i].getmpcity()<<endl;
        cout << "Population: "<<arr[i].getpopulation()<<endl;
        cout << "Area: "<<arr[i].getsqmiles()<< " mi2"<<endl;
        cout << "Time zones: "<<arr[i].gettimez1()<<", "<<arr[i].gettimez2()<<endl;
        cout << "DST: "<<arr[i].getdaylight()<<endl;
    }
    delete[] arr;
}








state* xmlfilereader(string filename,unsigned short &numofstates)
{
    //xml file reader
    state* statedata;

    numofstates = 0;
    string line;
    ifstream txtFile(filename);
    if (txtFile.is_open())
    {
        // get num of states
        while (getline(txtFile, line))
        {
            size_t pos = line.find("state name");
            if (pos!=string::npos)
            {
                numofstates++;
            }
        }
        txtFile.close();
    }
        // get num of states

    statedata=new (nothrow) state[numofstates]; //create array of class for data storage


    unsigned short k=0; //counter for array of state(which is our class) index

    string line2;
    ifstream sel(filename);
    if (sel.is_open())
    {
        while (getline(sel, line2))
        {
            size_t pos = line2.find("state name"); //pos state name
            if (pos!=string::npos)
            {

                char delimiterforequal = '=';
                size_t posofequal=0;
                //finding the element count for each line
                unsigned short counterofelements=0;
                while((posofequal=line2.find(delimiterforequal)) != string::npos)
                {
                    counterofelements++;
                    line2.erase(posofequal,1);
                }
                //finding the element count for each line
                char delimiter = '"';
                for(int i=0; i<counterofelements; i++)
                {
                    if(counterofelements==9)
                    {
                        if(i==0)
                        {
                            size_t pos1 = 0; //state name öncesi tırnak
                            size_t pos2 = 0; //state name sonrası tırnak
                            //getting the first element which is state name by using find and substr function
                            pos1 = line2.find(delimiter);
                            pos2 = line2.find(delimiter, pos1 +1);
                            size_t lenofasset = pos2-pos1-1;
                            string asset= line2.substr(pos1+1,lenofasset);
                            //getting the first element which is state name by using find and substr functions
                            statedata[k].setname(asset);
                            line2.erase(pos1,1);
                            line2.erase(pos2-1,1);

                        }
                        else if(i==1)
                        {
                            size_t pos1 = 0; //state name öncesi tırnak
                            size_t pos2 = 0; //state name sonrası tırnak
                            //getting the second element
                            pos1 = line2.find(delimiter, pos2+ 1);
                            pos2 = line2.find(delimiter, pos1 +1);
                            size_t lenofasset = pos2-pos1-1;
                            string asset= line2.substr(pos1+1,lenofasset);
                            //getting the second element
                            statedata[k].setabbreviation(asset);
                            line2.erase(pos1,1);
                            line2.erase(pos2-1,1);
                        }
                        else if(i==2)
                        {
                            size_t pos1 = 0;
                            size_t pos2 = 0;
                            pos1 = line2.find(delimiter, pos2+ 1);
                            pos2 = line2.find(delimiter, pos1 +1);
                            size_t lenofasset = pos2-pos1-1;
                            string asset= line2.substr(pos1+1,lenofasset);
                            statedata[k].setcapital(asset);
                            line2.erase(pos1,1);
                            line2.erase(pos2-1,1);
                        }
                        else if(i==3)
                        {
                            size_t pos1 = 0;
                            size_t pos2 = 0;
                            pos1 = line2.find(delimiter, pos2+ 1);
                            pos2 = line2.find(delimiter, pos1 +1);
                            size_t lenofasset = pos2-pos1-1;
                            string asset= line2.substr(pos1+1,lenofasset);
                            statedata[k].setdate(asset);
                            line2.erase(pos1,1);
                            line2.erase(pos2-1,1);
                        }
                        else if(i==4)
                        {
                            size_t pos1 = 0;
                            size_t pos2 = 0;
                            pos1 = line2.find(delimiter, pos2+ 1);
                            pos2 = line2.find(delimiter, pos1 +1);
                            size_t lenofasset = pos2-pos1-1;
                            string asset= line2.substr(pos1+1,lenofasset);
                            statedata[k].setmpcity(asset);
                            line2.erase(pos1,1);
                            line2.erase(pos2-1,1);
                        }
                        else if(i==5)
                        {
                            size_t pos1 = 0;
                            size_t pos2 = 0;
                            pos1 = line2.find(delimiter, pos2+ 1);
                            pos2 = line2.find(delimiter, pos1 +1);
                            size_t lenofasset = pos2-pos1-1;
                            string asset= line2.substr(pos1+1,lenofasset);
                            unsigned int popasint=strtoint(asset);//convert pop to int
                            statedata[k].setpopulation(popasint);
                            line2.erase(pos1,1);
                            line2.erase(pos2-1,1);
                        }
                        else if(i==6)
                        {
                            size_t pos1 = 0;
                            size_t pos2 = 0;
                            pos1 = line2.find(delimiter, pos2+ 1);
                            pos2 = line2.find(delimiter, pos1 +1);
                            size_t lenofasset = pos2-pos1-1;
                            string asset= line2.substr(pos1+1,lenofasset);
                            unsigned int areaasint=strtoint(asset);//convert area to int
                            statedata[k].setsqmiles(areaasint);
                            line2.erase(pos1,1);
                            line2.erase(pos2-1,1);
                        }
                        else if(i==7)
                        {
                            size_t pos1 = 0;
                            size_t pos2 = 0;
                            pos1 = line2.find(delimiter, pos2+ 1);
                            pos2 = line2.find(delimiter, pos1 +1);
                            size_t lenofasset = pos2-pos1-1;
                            string asset= line2.substr(pos1+1,lenofasset);
                            statedata[k].settimez1(asset);
                            line2.erase(pos1,1);
                            line2.erase(pos2-1,1);
                        }
                        else if(i==8)
                        {
                            size_t pos1 = 0;
                            size_t pos2 = 0;
                            pos1 = line2.find(delimiter, pos2+ 1);
                            pos2 = line2.find(delimiter, pos1 +1);
                            size_t lenofasset = pos2-pos1-1;
                            string asset= line2.substr(pos1+1,lenofasset);
                            statedata[k++].setdaylight(asset);
                            line2.erase(pos1,1);
                            line2.erase(pos2-1,1);
                        }
                    }
                    if(counterofelements==10)
                    {
                        if(i==0)
                        {
                            size_t pos1 = 0; //state name öncesi tırnak
                            size_t pos2 = 0; //state name sonrası tırnak
                            //getting the first element which is state name by using find and substr function
                            pos1 = line2.find(delimiter);
                            pos2 = line2.find(delimiter, pos1 +1);
                            size_t lenofasset = pos2-pos1-1;
                            string asset= line2.substr(pos1+1,lenofasset);
                            //getting the first element which is state name by using find and substr functions
                            statedata[k].setname(asset);
                            line2.erase(pos1,1);
                            line2.erase(pos2-1,1);

                        }
                        else if(i==1)
                        {
                            size_t pos1 = 0;
                            size_t pos2 = 0;
                            //getting the second element
                            pos1 = line2.find(delimiter, pos2+ 1);
                            pos2 = line2.find(delimiter, pos1 +1);
                            size_t lenofasset = pos2-pos1-1;
                            string asset= line2.substr(pos1+1,lenofasset);
                            //getting the second element
                            statedata[k].setabbreviation(asset);
                            line2.erase(pos1,1);
                            line2.erase(pos2-1,1);
                        }
                        else if(i==2)
                        {
                            size_t pos1 = 0;
                            size_t pos2 = 0;
                            pos1 = line2.find(delimiter, pos2+ 1);
                            pos2 = line2.find(delimiter, pos1 +1);
                            size_t lenofasset = pos2-pos1-1;
                            string asset= line2.substr(pos1+1,lenofasset);
                            statedata[k].setcapital(asset);
                            line2.erase(pos1,1);
                            line2.erase(pos2-1,1);
                        }
                        else if(i==3)
                        {
                            size_t pos1 = 0;
                            size_t pos2 = 0;
                            pos1 = line2.find(delimiter, pos2+ 1);
                            pos2 = line2.find(delimiter, pos1 +1);
                            size_t lenofasset = pos2-pos1-1;
                            string asset= line2.substr(pos1+1,lenofasset);
                            statedata[k].setdate(asset);
                            line2.erase(pos1,1);
                            line2.erase(pos2-1,1);
                        }
                        else if(i==4)
                        {
                            size_t pos1 = 0;
                            size_t pos2 = 0;
                            pos1 = line2.find(delimiter, pos2+ 1);
                            pos2 = line2.find(delimiter, pos1 +1);
                            size_t lenofasset = pos2-pos1-1;
                            string asset= line2.substr(pos1+1,lenofasset);
                            statedata[k].setmpcity(asset);
                            line2.erase(pos1,1);
                            line2.erase(pos2-1,1);
                        }
                        else if(i==5)
                        {
                            size_t pos1 = 0;
                            size_t pos2 = 0;
                            pos1 = line2.find(delimiter, pos2+ 1);
                            pos2 = line2.find(delimiter, pos1 +1);
                            size_t lenofasset = pos2-pos1-1;
                            string asset= line2.substr(pos1+1,lenofasset);
                            unsigned int popasint=strtoint(asset);//convert pop to int
                            statedata[k].setpopulation(popasint);
                            line2.erase(pos1,1);
                            line2.erase(pos2-1,1);
                        }
                        else if(i==6)
                        {
                            size_t pos1 = 0;
                            size_t pos2 = 0;
                            pos1 = line2.find(delimiter, pos2+ 1);
                            pos2 = line2.find(delimiter, pos1 +1);
                            size_t lenofasset = pos2-pos1-1;
                            string asset= line2.substr(pos1+1,lenofasset);
                            unsigned int areaasint=strtoint(asset);//convert area to int
                            statedata[k].setsqmiles(areaasint);
                            line2.erase(pos1,1);
                            line2.erase(pos2-1,1);
                        }
                        else if(i==7)
                        {
                            size_t pos1 = 0;
                            size_t pos2 = 0;
                            pos1 = line2.find(delimiter, pos2+ 1);
                            pos2 = line2.find(delimiter, pos1 +1);
                            size_t lenofasset = pos2-pos1-1;
                            string asset= line2.substr(pos1+1,lenofasset);
                            statedata[k].settimez1(asset);
                            line2.erase(pos1,1);
                            line2.erase(pos2-1,1);
                        }
                        else if(i==8)
                        {
                            size_t pos1 = 0;
                            size_t pos2 = 0;
                            pos1 = line2.find(delimiter, pos2+ 1);
                            pos2 = line2.find(delimiter, pos1 +1);
                            size_t lenofasset = pos2-pos1-1;
                            string asset= line2.substr(pos1+1,lenofasset);
                            statedata[k].settimez2(asset);
                            line2.erase(pos1,1);
                            line2.erase(pos2-1,1);
                        }
                        else if(i==9)
                        {
                            size_t pos1 = 0;
                            size_t pos2 = 0;
                            pos1 = line2.find(delimiter, pos2+ 1);
                            pos2 = line2.find(delimiter, pos1 +1);
                            size_t lenofasset = pos2-pos1-1;
                            string asset= line2.substr(pos1+1,lenofasset);
                            statedata[k++].setdaylight(asset);
                            line2.erase(pos1,1);
                            line2.erase(pos2-1,1);
                        }
                    }

                }
            }

        }
    }
    sel.close();
    return statedata;
}

void query1()
{

    unsigned short numofstates;
    state* afa = xmlfilereader("us_states.xml",numofstates);
    printerforquery1(afa,numofstates);
}

void query2()
{
    unsigned short numofstates;
    state* doga = xmlfilereader("us_states.xml",numofstates);
    sorterforquery2(doga,numofstates);
    printerforquery2(doga,numofstates);
}

void query3()
{
    unsigned short numofstates;
    state* kasim = xmlfilereader("us_states.xml",numofstates);
    sorterforquery3(kasim,numofstates);
    printerforquery3(kasim,5);
}
void query4()
{
    unsigned short numofstates;
    state* enes = xmlfilereader("us_states.xml",numofstates);
    sorterforquery4(enes,numofstates);
    printerforquery4(enes,numofstates);
}
void query5()
{
    unsigned short numofstates;
    state* fabio = xmlfilereader("us_states.xml",numofstates);
    unsigned int totalarea=0;
    for(unsigned short i=0;i<numofstates;i++)
    {
        totalarea=totalarea+fabio[i].getsqmiles();
    }
    unsigned int overallarea=totalarea/numofstates;
    cout << "Overall area of United States is "<<overallarea<<" mi2"<<endl;
    delete[] fabio;
}
void query6()
{
    unsigned short numofstates;
    state* dogakasimafa = xmlfilereader("us_states.xml",numofstates);
    unsigned int totalpop=0;
    for(unsigned short i=0;i<numofstates;i++)
    {
        totalpop=totalpop+dogakasimafa[i].getpopulation();
    }
    unsigned int overallpop=totalpop/numofstates;
    cout << "Overall population of United States is "<<overallpop<<endl;
    delete[] dogakasimafa;
}





#endif // FUNCTIONS_H_INCLUDED
