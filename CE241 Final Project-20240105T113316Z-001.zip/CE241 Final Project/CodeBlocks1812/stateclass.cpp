#include <iostream>
#include <string>
#include <new>
#include <climits>
#include <fstream>
#include "stateclass.h"

using namespace std;

void state::setname(string name)
{
    this->name = name;
}
void state::setabbreviation(string abbreviation)
{

	this->abbreviation = abbreviation;
}
void state::setcapital(string capital)
{
	this->capital = capital;
}
void state::setmpcity(string mpcity)
{
	this->mpcity = mpcity;
}
void state::settimez1(string timez1)
{
	this->timez1 = timez1;
}
void state::settimez2(string timez2)
{
	this->timez2 = timez2;
}
void state::setdate(unsigned short date)
{
	this->date = date;
}
void state::setpopulation(unsigned short population)
{
	this->population = population;
}
void state::setsqmiles(unsigned short sqmiles)
{
	this->sqmiles = sqmiles;
}

string state::getname(void)
{
	return name;
}
string state::getabbreviation(void)
{
	return abbreviation;
}
string state::getcapital(void)
{
	return capital;
}
string state::getmpcity(void)
{
	return mpcity;
}
string state::gettimez1(void)
{
	return timez1;
}
string state::gettimez2(void)
{
	return timez2;
}
unsigned short state::getdate(void)
{
	return date;
}
unsigned short state::getpopulation(void)
{
	return population;
}
unsigned short state::getsqmiles(void)
{
	return sqmiles;
}

