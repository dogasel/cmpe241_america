#include <iostream>
#include <string>
#include <new>
#include <climits>
#include <fstream>
#include "stateclass.h"
#include "functions.h"



using namespace std;

int main()
{
    unsigned short numofcapitals;
    capitals* enes;
    enes=structureforcitys("us_states.xml",numofcapitals);
    capitalprinter(enes,numofcapitals);
    sorter(enes,numofcapitals);
    capitalprinter(enes,numofcapitals);


}



