#ifndef STATECLASS_H
#define STATECLASS_H
#include <iostream>
#include <string>
#include <new>
#include <climits>
#include <fstream>

using namespace std;



class state
{
	string name, abbreviation, capital, dateasstring, mpcity, timez1, timez2;
	unsigned short date, population, sqmiles;

public:
    state();
    ~state();

	void setname(string name);
	void setabbreviation(string abbreviation);
	void setcapital(string capital);
	void setmpcity(string mpcity);
	void settimez1(string timez1);
	void settimez2(string timez2);
	void setdate(unsigned short date);
	void setpopulation(unsigned short population);
	void setsqmiles(unsigned short sqmiles);

	string getname(void);
	string getabbreviation(void);
	string getcapital(void);
	string getmpcity(void);
	string gettimez1(void);
	string gettimez2(void);
	unsigned short getdate(void);
	unsigned short getpopulation(void);
	unsigned short getsqmiles(void);
};

class Date
{
 public:
    unsigned short month;
    unsigned short day;
    unsigned short year;
};

#endif


