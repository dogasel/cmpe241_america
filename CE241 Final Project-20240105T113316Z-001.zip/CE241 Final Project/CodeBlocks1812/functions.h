#ifndef FUNCTIONS_H_INCLUDED
#define FUNCTIONS_H_INCLUDED
#include <iostream>
#include <string>
#include <new>
#include <climits>
#include <fstream>
#include <string.h>
#include <stdio.h>

struct capitals
    {
        public:
        string capital;
        string abbreviation;
    };



unsigned short strtoint(string str)
{
    unsigned short ans=0;
    unsigned short times=1;
    for(int i=str.length()-1;i>=0;i--)
    {
        ans=ans+times*(str[i]-'0');
        times=times*10;
    }
    return ans;

}

void datetransfer(string dt)
{
    string year = dt.substr(0,4);
    string month = dt.substr(5,2);
    string day = dt.substr(8,2);
    unsigned short year2 = strtoint(year);
    unsigned short month2 = strtoint(month);
    unsigned short day2 = strtoint(day);

    string months[12] ={ "January", "February", "March", "April", "May", "June",
 "July", "August", "September", "October", "November", "December" };

    Date afa;

    afa.year=year2;
    afa.month=month2;
    afa.day=day2;

    cout << months[month2-1] <<" "<<day<<", "<<year2;

}




void arrayprinter(string *arr,int counter)
{
    for(int i=0;i<counter;i++)
    {
        if(counter==9)
        {
            if(i==0)
                cout << "State: "<<arr[i]<<endl;
            if(i==1)
                cout << "Abbreviation: "<<arr[i]<<endl;
            if(i==2)
                cout << "Capital: "<<arr[i]<<endl;
            if(i==3)
            {
                cout << "Date of admission: ";
                datetransfer(arr[i]);
                cout<<endl;
            }
            if(i==4)
                cout << "Most populous city: "<<arr[i]<<endl;
            if(i==5)
                cout << "Population: "<<arr[i]<<endl;
            if(i==6)
                cout << "Area: "<<arr[i]<< " mi2"<<endl;
            if(i==7)
                cout << "Time zones: "<<arr[i]<<endl;
            if(i==8)
                cout << "Dst: "<<arr[i]<<endl;
        }
        if(counter==10)
        {
            if(i==0)
                cout << "State: "<<arr[i]<<endl;
            if(i==1)
                cout << "Abbreviation: "<<arr[i]<<endl;
            if(i==2)
                cout << "Capital: "<<arr[i]<<endl;
            if(i==3)
            {
                cout << "Date of admission: ";
                datetransfer(arr[i]);
                cout<<endl;
            }
            if(i==4)
                cout << "Most populous city: "<<arr[i]<<endl;
            if(i==5)
                cout << "Population: "<<arr[i]<<endl;
            if(i==6)
                cout << "Area: "<<arr[i]<< " mi2"<<endl;
            if(i==7)
                cout << "Time zones: "<<arr[i]<<", "<<arr[i+1]<<endl;
            if(i==8)
                cout << "DST: "<<arr[i+1]<<endl;
        }

    }
}

void query1()
{

string state;
cout << "Type a name of state to retrieve info: ";

cin >> state;


string line, name = "us_states.xml";
ifstream txtFile("us_states.xml");

int counter;
string *arrayofelements;

if (txtFile.is_open())
{
	while (getline(txtFile, line))
    {
        size_t pos = line.find(state);
        if (pos!=string::npos) //aldığı line içinde cin ile aldığımız state var ise
        {
            //count of items
            counter = 0;
            for (int i = 0; i < line.size(); i++)
            {
                if (line[i] == '"') counter++;
            }
            counter=counter/2;
            //count of items
            arrayofelements = new (nothrow) string[counter];
            unsigned short k=0;


            for (int i=0; i<counter;i++)
            {

                char delimiter = '"';
                size_t pos = 0;
                size_t pos2 = 0;
                pos = line.find(delimiter);
                pos2 = line.find(delimiter, pos +1);
                size_t lenofasset = pos2-pos-1;
                string asset= line.substr(pos+1,lenofasset);
                line.erase(0,pos2+1);
                arrayofelements[k++]=asset;
            }


        }

    }

        //element getter

}
    arrayprinter(arrayofelements,counter);
    delete[] arrayofelements;
    txtFile.close();
}




capitals* structureforcitys(string filename,unsigned short &numofcapitals)
{
    numofcapitals = 0;
    capitals* capitallist;
    string line;
    ifstream txtFile("us_states.xml");
    if (txtFile.is_open())
    {
        while (getline(txtFile, line))
        {
            size_t pos = line.find("capital");
            if (pos!=string::npos) //aldığı line içinde cin ile aldığımız state var ise
            {
              numofcapitals++;
            }
        }

        capitallist=new (nothrow) capitals[numofcapitals];

        unsigned short k=0;

        string line2;
        ifstream anan("us_states.xml");
        while (getline(anan, line2))
        {
            size_t pos = line2.find("capital");
            if (pos!=string::npos)
            {
                char delimiter = '"';
                size_t pos2 = 0;
                size_t pos3 = 0;
                pos2 = line2.find(delimiter,pos +1);
                pos3 = line2.find(delimiter, pos2 +1);
                size_t lenofasset = pos3-pos2-1;
                string nameofcapital= line2.substr(pos2+1,lenofasset);
                capitallist[k].capital=nameofcapital;
                string abbreviation= line2.substr(pos2-12,2);
                capitallist[k++].abbreviation=abbreviation;
            }
        }
    }
    cout << "Capitals has been generated!"<<endl;
    txtFile.close();
    return capitallist;
}

void swaper(capitals &item1,capitals &item2)
{
    string tempforcapital, tempforabbreviation;
    tempforcapital=item1.capital;
    tempforabbreviation=item1.abbreviation;
    item1.capital=item2.capital;
    item1.abbreviation=item2.abbreviation;
    item2.capital=tempforcapital;
    item2.abbreviation=tempforabbreviation;
}

void sorter(capitals* obj,unsigned short numofcapitals)
{
    for(int i=0;i<numofcapitals-1;i++)
    {
        for(int j=i+1;j<numofcapitals;j++)
        {

            int res = obj[i].capital.compare(obj[j].capital);
            if(res>0)
            {
                swaper(obj[i],obj[j]);
            }

        }

    }
    cout << "Has been sorted" << endl;
}



void capitalprinter(capitals* obj,unsigned short numofcapitals)
{
    for(int i=0;i<numofcapitals;i++)
    {
        cout << obj[i].capital << " (" <<obj[i].abbreviation <<")"<< endl;
    }

}







#endif // FUNCTIONS_H_INCLUDED
