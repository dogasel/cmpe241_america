#include <iostream>
#include <string>
#include <new>
#include <climits>
#include <fstream>
#include "stateclass.h"
#include "functions.h"



using namespace std;

int main()
{
    unsigned short numofstates;
    state* afa = xmlfilereader("us_states.xml",numofstates);

}
